import Cocoa
//
//func greeting() {
//    print("Hello World!")
//}
//
//func greet(name: String) {
//    print("Hello, \(name)")
//}
//
//func add(lhs: Int, rhs: Int) -> Int {
//    lhs + rhs
//}
//
//greeting()
//let name = "Sam"
//greet(name: name)
//
//let summ = add(lhs: 4, rhs: 4)
//print(summ)
//
////func addition(_ lhs: Int, _ rhs: Int) -> Int {
////    lhs + rhs
////}
//
////addition(1, 2)
//
//func increment(by number: Int) -> Int {
//    return number + 1
//}
//
//increment(by: 4)
//
//func maxAndMin(array: [Int]) -> (max: Int, min: Int) {
//    let max = array.max()! // Optional -> Later
//    let min = array.min()!
//
//    return (max, min)
//}
//
//func newGreeting(_ name: String = "Kate") {
//    print("Greet \(name)")
//}
//
//newGreeting("Juli")
//newGreeting()
//
//func average(_ numbers: Int...) -> Int {
//    var result = 0
//    for number in numbers {
//        result += number
//    }
//
//    return result / numbers.count
//}
//
//print(average(1, 2, 3, 4, 5))
//
//func incrementNumber(_ number: inout Int) {
//    number += 1
//}
//
//var selectedNumber = 4
//incrementNumber(&selectedNumber)
//
//print(selectedNumber)
//
//incrementNumber(&selectedNumber)
//print(selectedNumber)
//
//
//// (Int, Int) -> Int
//func add(_ lhs: Int, _ rhs: Int) -> Int {
//    return lhs + rhs
//}
//
//func mul(x: Int, y: Int) -> Int {
//    return x * y
//}
//
//func printMathStatement(_ math: (Int, Int) -> Int, a: Int, b: Int) {
//    let result = math(a, b)
//    print("Result of statement: \(result)")
//}
//
//printMathStatement(mul(x:y:), a: 2, b: 2)
//printMathStatement(add(_:_:), a: 4, b: 9)
//
//
//// (Int) -> Int
//func increment(x: Int) -> Int {
//    return x + 1
//}
//
//func decrement(y: Int) -> Int {
//    return y - 1
//}
//
//func chooseStep(isForward: Bool) -> ((Int) -> Int) {
//    if isForward {
//        return increment(x:)
//    } else {
//        return decrement(y:)
//    }
//}
//
//let stepFunction = chooseStep(isForward: false)
//stepFunction(1)
//
//var closure: (Int) -> Int
//
//closure = { number in
//    return number + 2
//}
//
//closure(2)
//
let fruits = ["🍎", "🍊", "🍌"]
//
//fruits.forEach { fruitItem in
//    print("Fruit: \(fruitItem)")
//}
//

var numbers = [1, 9, 2, 5, 8, 3]

numbers.sort { $0 < $1 }

let filtered = numbers.filter { $0 % 2 == 0 }

//print(numbers)
//print(filtered)


func makeRequest(with name: String, completion: (String) -> Void) {
    print("Loading...")
    sleep(2)
    print("Completed!")
    let resultMessage = "Welcome to our System: \(name)"
    completion(resultMessage)
}

//makeRequest(with: "Samantha") { message in
//    print(message)
//}

enum MathError: Error {
    case zeroDivision
}

func divide(a: Int, b: Int) throws -> Int {
    if b == 0 {
        throw MathError.zeroDivision
    }

    return a / b
}

do {
    let result = try divide(a: 4, b: 2)
    print(result)
} catch {
    print(error)
}

// null - nil
let emptyString = ""

var optionalNumber: Int? = 5

let stringNumber = "123"

//let casted = Int(stringNumber)
//if casted != nil {
//    let result = Int(stringNumber)! + 2
//    print(result)
//}

/// If Let
//if let unwraped = Int(stringNumber) {
//    let result = unwraped + 2
//    print(result)
//} else {
//    print("Error while parsing")
//}
//
///// Guard Let
//guard let safeNumber = Int(stringNumber) else {
//    print("Error while parsing")
//    fatalError()
//}
//
//let result = safeNumber + 2
//print(result)


let someString = "123"
let maybeInt = Int(someString) ?? 0 // nil-coalescing

let summ = maybeInt + 1
print(summ)
